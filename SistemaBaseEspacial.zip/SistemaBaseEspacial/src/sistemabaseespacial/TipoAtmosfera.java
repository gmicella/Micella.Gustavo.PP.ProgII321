package sistemabaseespacial;

public enum TipoAtmosfera {
    PRESURIZADA,
    VACIO
}
