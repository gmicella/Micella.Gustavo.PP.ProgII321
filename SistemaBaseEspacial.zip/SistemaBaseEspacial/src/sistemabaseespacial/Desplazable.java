package sistemabaseespacial;

public interface Desplazable {
    String desplazar();
}
